define({"button.toggledragdrop.tooltip":"Toggle Drag & Drop"});
