// sc scripts

$( document ).ready( function() {
	$( 'html' ).addClass( 'ready' );
});