define({"button.createulist.tooltip":"Unsortierte Liste einf\u00fcgen",
"button.createolist.tooltip":"Sortierte Liste einf\u00fcgen",
"button.indentlist.tooltip":"Liste niedriger schieben",
"button.outdentlist.tooltip":"Liste h\u00F6her schieben",
"floatingmenu.tab.list":"Liste"});